package com.cg.paymentwallet.test;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;







import com.cg.paymentwallet.bean.CustomerBean;
import com.cg.paymentwallet.exception.CustomerException;
import com.cg.paymentwallet.service.CustomerServiceImpl;
import com.cg.paymentwallet.service.ICustomerService;

public class CustomerServiceImplTest {
	private static ICustomerService custService = null;

	@BeforeClass
	public static void createInstance() {
		custService = new CustomerServiceImpl();
	}

	@Test(expected = CustomerException.class)
	public void testMobileForLength() throws Exception {
		CustomerBean customer = new CustomerBean();
		customer.setMobileNumber("9030113454");
		boolean result = custService.validate(customer);
		assertFalse(result);
	}

	@Test(expected = CustomerException.class)
	public void testMobileForAlpha() throws Exception {
		CustomerBean customer = new CustomerBean();
		customer.setMobileNumber("abcd");
		boolean result = custService.validate(customer);
		assertFalse(result);
	}

	@Test(expected = CustomerException.class)
	public void testMobileForEmpty() throws Exception {
		CustomerBean customer = new CustomerBean();
		customer.setMobileNumber(" ");
		boolean result = custService.validate(customer);
		assertFalse(result);
	}
	
	@Test
	public void testMobileNo()   {
		CustomerBean customer = new CustomerBean();
		customer.setMobileNumber("9030113454");
		boolean result=false;
		try {
			result = custService.validate(customer);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Assert.fail("");
		}
		assertFalse(result);
	}
}
