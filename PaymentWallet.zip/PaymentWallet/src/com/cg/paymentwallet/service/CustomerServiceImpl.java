package com.cg.paymentwallet.service;

import com.cg.paymentwallet.bean.CustomerBean;
import com.cg.paymentwallet.dao.CustomerDaoImpl;
import com.cg.paymentwallet.dao.ICustomerDao;
import com.cg.paymentwallet.exception.CustomerException;
import com.cg.paymentwallet.exception.CustomerMessage;

public class CustomerServiceImpl implements ICustomerService {
	ICustomerDao dao = new CustomerDaoImpl();

	@Override
	public boolean createAccount(CustomerBean customer) {
		// TODO Auto-generated method stub
		return dao.createAccount(customer);
	}

	@Override
	public double showBalance(String accNum,String mobileNumber) {
		// TODO Auto-generated method stub

		return dao.showBalance(accNum,mobileNumber);
	}

	@Override
	public double deposit(String accNum) {
		// TODO Auto-generated method stub
		return dao.deposit(accNum);
	}

	@Override
	public double withdraw(String accNum) {
		// TODO Auto-generated method stub
		return dao.withdraw(accNum);
	}

	@Override
	public double fundTransfer(String accNum) {
		// TODO Auto-generated method stub
		return dao.fundTransfer(accNum);
	}

	@Override
	public void printTransactions(String accNum) {
		// TODO Auto-generated method stub
		dao.printTransactions(accNum);
	}

	@Override
	public boolean validate(CustomerBean customer) throws Exception {
		// TODO Auto-generated method stub
		boolean isValid = false;
		String regex = "\\d+";
		String prefix = "[6-9]";
		String accNum = "547648976495";
		if (!(customer.getMobileNumber().trim().length() == 10)) {

			throw new CustomerException(CustomerMessage.ERROR1);

		} else if (customer.getMobileNumber().isEmpty()) {

			throw new CustomerException(CustomerMessage.ERROR2);
		} else if (!(customer.getMobileNumber().matches(regex))) {

			throw new CustomerException(CustomerMessage.ERROR3);
		} else if (!(customer.getMobileNumber().startsWith(prefix))) {

			throw new CustomerException(CustomerMessage.ERROR4);
		} else if (!(accNum.contains(regex))) {

			throw new CustomerException(CustomerMessage.ERROR5);
		} else if (accNum.isEmpty()) {

			throw new CustomerException(CustomerMessage.ERROR6);
		} else {
			isValid = true;
		}
		return isValid;
	}

}
