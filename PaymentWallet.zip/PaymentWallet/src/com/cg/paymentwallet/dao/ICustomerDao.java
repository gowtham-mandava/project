package com.cg.paymentwallet.dao;

import com.cg.paymentwallet.bean.CustomerBean;

public interface ICustomerDao {
	 public boolean createAccount(CustomerBean customer);
	 public double showBalance(String accNum,String mobileNumber);
	 public double deposit(String accNum);
	 public double withdraw(String accNum);
	 public double fundTransfer(String accNum);
	 public void printTransactions(String accNum);

}
