package com.cg.paymentwallet.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.paymentwallet.bean.CustomerBean;

public class CustomerDaoImpl implements ICustomerDao {
List<CustomerBean> custList=new ArrayList<>();
CustomerBean customer=new CustomerBean();
@Override
	public boolean createAccount(CustomerBean customer) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public double showBalance(String accNum,String mobileNumber) {
		// TODO Auto-generated method stub
		double balance=0;
	    mobileNumber="9030113454";
	
		custList.add(customer);
        for (CustomerBean customer : custList) {
			if(customer.getMobileNumber()==mobileNumber){ 
        	 balance=customer.getBalance();
			}
			
			}       
      return balance;
	}

	@Override
	public double deposit(String accNum) {
		// TODO Auto-generated method stub
		
		return 0;
	}

	@Override
	public double withdraw(String accNum) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double fundTransfer(String accNum) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void printTransactions(String accNum) {
		// TODO Auto-generated method stub

	}

	
	
}
