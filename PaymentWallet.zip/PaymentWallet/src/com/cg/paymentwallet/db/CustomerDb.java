package com.cg.paymentwallet.db;

import java.util.TreeMap;

import com.cg.paymentwallet.bean.CustomerBean;

public class CustomerDb {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    TreeMap<Integer,CustomerBean> tCustomer=new TreeMap<>();
    CustomerBean customer1=new CustomerBean();
    
	}

}
