package com.cg.paymentwallet.exception;

public class CustomerMessage extends Exception{
public static final String ERROR1="mobile number must be minimum of 10 digits";
public static final String ERROR2="mobile number must not be empty";
public static final String ERROR3="mobile number must only contains numbers";
public static final String ERROR4="mobile number must start with 6 or 7 or 8 or 9";
public static final String ERROR5="account number must contain only numbers";
public static final String ERROR6="account number must not be empty";
}
