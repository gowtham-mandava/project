package com.cg.miniproject.dao;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.cg.miniproject.bean.CustomerBean;
import com.cg.miniproject.exception.CustomerException;
import com.cg.miniproject.exception.CustomerMessage;

public class CustomerDaoImpl implements ICustomerDao {
List<CustomerBean> list=new ArrayList<>();
CustomerBean customer=new CustomerBean();

	@Override
	public boolean createAccount(CustomerBean customer) throws Exception {
		// TODO Auto-generated method stub
		boolean isAdded=false;
		String regex="\\d+";
		customer.getFirstName();
		customer.getLastName();
		customer.getMobileNumber();
		customer.getAccNum();
		customer.getBalance();
		list.add(customer);
		if(customer.getFirstName().trim().length()<4) {
			throw new CustomerException(CustomerMessage.ERROR1);
		}
		else if(customer.getFirstName().isEmpty()){
			throw new CustomerException(CustomerMessage.ERROR2);
		}
		else if(customer.getFirstName().contains(regex)) {
			throw new CustomerException(CustomerMessage.ERROR3);
		}
		else if(customer.getLastName().trim().length()<4) {
			throw new CustomerException(CustomerMessage.ERROR4);
		}
		else if(customer.getLastName().isEmpty()){
			throw new CustomerException(CustomerMessage.ERROR5);
		}
		else if(customer.getLastName().contains(regex)) {
			throw new CustomerException(CustomerMessage.ERROR6);
		}
		else if(customer.getMobileNumber().isEmpty()) {
			throw new CustomerException(CustomerMessage.ERROR7);
		}
		else if(!(customer.getMobileNumber().matches(regex))) {
			throw new CustomerException(CustomerMessage.ERROR8);
		}
		else if(!(customer.getMobileNumber().length()==10)) {
			throw new CustomerException(CustomerMessage.ERROR9);
		}
		return isAdded;
	}

	@Override
	public double showBalance(String mobileNumber) {
		// TODO Auto-generated method stub
         double balance=0;
         for (CustomerBean cust : list) {
			if(cust.getMobileNumber()==mobileNumber) {
				balance=cust.getBalance()+balance;
			}
		}
         
		return balance;
	}

	@Override
	public double deposit(double amount) {
		// TODO Auto-generated method stub
		
		double balance=customer.getBalance()+customer.getAmount();
		return balance;
	}

	@Override
	public double withdraw(double amount) {
		// TODO Auto-generated method stub
		double balance=customer.getBalance()-customer.getAmount();
		return balance;
	}

	@Override
	public double fundTransfer(String mobileNumber) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void printTransactions(BigInteger accNum) {
		// TODO Auto-generated method stub

	}

}
