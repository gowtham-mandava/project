package com.cg.miniproject.dao;

import java.math.BigInteger;

import com.cg.miniproject.bean.CustomerBean;

public interface ICustomerDao {
	public boolean createAccount(CustomerBean customer) throws Exception;

	public double showBalance(String mobileNumber);

	public double deposit(double amount);

	public double withdraw(double amount);

	public double fundTransfer(String mobileNumber);

	public void printTransactions(BigInteger accNum);
}
