package com.cg.miniproject.exception;

public class CustomerMessage extends Exception{
 
	 public static final String ERROR1=" first name must be minimum 4 characters";
	 public static final String ERROR2=" first name should not be empty";
	 public static final String ERROR3=" first name should not contain numbers";
	 public static final String ERROR4="last name must be minimum 4 characters";
	 public static final String ERROR5=" last name should not be empty";
	 public static final String ERROR6=" last name should not contain numbers";
	 public static final String ERROR7=" mobile number should not be empty";
	 public static final String ERROR8=" mobile number should contain numbers";
	 public static final String ERROR9=" mobile number should contain only 10 digits";
}
