package com.cg.miniproject.service;


import java.math.BigInteger;

import com.cg.miniproject.bean.CustomerBean;

public interface ICustomerService {
	public boolean createAccount(CustomerBean customer) throws Exception;

	public double showBalance(String mobileNumber);

	public double deposit(double amount);

	public double withdraw(double amount);

	public double fundTransfer(String mobileNumber);

	public void printTransactions(BigInteger accNum);

}
