package com.cg.miniproject.service;

import java.math.BigInteger;

import com.cg.miniproject.bean.CustomerBean;
import com.cg.miniproject.dao.CustomerDaoImpl;
import com.cg.miniproject.dao.ICustomerDao;

public class CustomerServiceImpl implements ICustomerService {
ICustomerDao dao=new CustomerDaoImpl();
	@Override
	public boolean createAccount(CustomerBean customer) throws Exception {
		// TODO Auto-generated method stub
		return dao.createAccount(customer);
	}

	@Override
	public double showBalance(String mobileNumber) {
		// TODO Auto-generated method stub
		return dao.showBalance(mobileNumber);
	}

	@Override
	public double deposit(double amount) {
		// TODO Auto-generated method stub
		return dao.deposit(amount);
	}

	@Override
	public double withdraw(double amount) {
		// TODO Auto-generated method stub
		return dao.withdraw(amount);
	}

	@Override
	public double fundTransfer(String mobileNumber) {
		// TODO Auto-generated method stub
		return dao.fundTransfer(mobileNumber);
	}

	@Override
	public void printTransactions(BigInteger accNum) {
		// TODO Auto-generated method stub
        dao.printTransactions(accNum);
	}

}
